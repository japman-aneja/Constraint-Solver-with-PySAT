"""
sudoku_solver.py

Implement the function `solve_sudoku(grid: List[List[int]]) -> List[List[int]]` using a SAT solver from PySAT.
"""

from pysat.formula import CNF
from pysat.solvers import Solver
from typing import List

def bij(r,c,d):
    return r * 100 + c * 10 + d

def solve_sudoku(grid: List[List[int]]) -> List[List[int]]:
    """Solves a Sudoku puzzle using a SAT solver. Input is a 2D grid with 0s for blanks."""

    # TODO: implement encoding and solving using PySAT
    cnf = CNF()

    # Initial condition constraints and constraint that each cell must contain exactly one digit from 1 to 9.
    for r in range(9):
        for c in range(9):
            #initial condition constraint: if value in a cell is non-zero means that it must contain a fixed digit d
            if grid[r][c] != 0:
                cnf.append([bij(r, c, grid[r][c])])
            else:
                # each cell must contain atleast one digit
                cnf.append([bij(r, c, d) for d in range(1, 10)])  
                # each cell must contain atmost one digit
                for d1 in range(1,9):
                    for d2 in range (d1+1,10):
                        cnf.append([-bij(r,c,d1),-bij(r,c,d2)])
    
    # Constraint that each digit must appear exactly once in every row.
    for r in range(9) :
        for digit in range(1,10) :
            clauses = []
            # each digit appears atleast once per row
            for column in range(9) :
                # (r,c,d) disjunction is added as a clause 
                clauses.append(bij(r,column,digit))
            cnf.append(clauses)
            # each digit appears atmost once in each row
            for c1 in range(9):
                for c2 in range(c1 + 1, 9):
                    cnf.append([-bij(r, c1, digit), -bij(r, c2, digit)])

    # Constraint that each digit must appear exactly once in every column.
    for column in range(9) :
        for digit in range(1,10) :
            clauses = []
            # each digit appears atleast once per column
            for row in range(9) :
                # (r,c,d) disjunction is added as a clause
                clauses.append(bij(row,column,digit))
            cnf.append(clauses)
            # each digit appears atmost once in each column
            for r1 in range(9):
                for r2 in range(r1 + 1, 9):
                    cnf.append([-bij(r1, column, digit), -bij(r2, column, digit)])

    # Constraint that each digit must appear exactly once in every 3x3 subgrid.
    for row in range(0,9,3) :
        for column in range(0,9,3) :
            # this denotes a 3x3 subgrid of the sudoku
            for digit in range(1,10) :
                clauses = []
                # each digit appears atleast once in every 3x3 subgrid
                for r in range(row, row+3) :
                    for c in range(column, column + 3) :
                        clauses.append(bij(r,c,digit))
                cnf.append(clauses)
                # each digit appears atmost once in every 3x3 subgrid
                for i in range(len(clauses)):
                    for j in range(i + 1, len(clauses)):
                        cnf.append([-clauses[i], -clauses[j]])


    with Solver(name='glucose3') as solver:
        solver.append_formula(cnf.clauses)
        solved_grid = [[0 for _ in range(9)] for _ in range(9)]
        if solver.solve():
            model = solver.get_model()
            for i in model:
                if i >0:
                    d = i % 10
                    c = (i // 10) % 10
                    r = i // 100
                    solved_grid[int(r)][int(c)] = d
            return solved_grid        
        else:
            return []

        